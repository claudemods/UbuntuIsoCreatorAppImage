# README
## copyng on (efi.img) /home/eggs/.mnt/efi/mnt/
/home/eggs/.mnt/efi/memdisk//boot/grub/grub.cfg copied to /boot/grubcreated grubx64.efi not signed and copied as  bootx64.efi

## Copyng on /home/eggs/.mnt/iso/
rsync -avx /home/eggs/.mnt/efi/work//boot (iso)/boot
